from setuptools import setup

setup(name='mar_distributions',
      version='0.1234',
      description='Gaussian distributions and Binomial distributions',
      packages=['mar_distributions'],
      zip_safe=False)
